"use strict";
(() => {
  // src/messaging/core.ts
  var WebKernel = class {
    requestPool = /* @__PURE__ */ new Map();
    channel;
    constructor(channel) {
      this.channel = channel;
      window.addEventListener("message", async ({ data }) => {
        const message = data;
        if (message.type === "response" /* Response */) {
          const resolver = this.requestPool.get(message.id);
          if (!resolver)
            return;
          resolver.resolve(message);
        }
        if (message.type === "request" /* Request */ && message.to === this.channel && this.handleRequest) {
          const response = {
            id: message.id,
            type: "response" /* Response */,
            from: this.channel,
            to: message.from,
            payload: null
          };
          try {
            const payload = await this.handleRequest(message);
            response.payload = payload;
          } catch (error) {
            response.type = "reject" /* Reject */;
            response.payload = error.message;
          }
          window.postMessage(response, "*");
        }
        if (message.type === "reject" /* Reject */) {
          const resolver = this.requestPool.get(message.id);
          if (!resolver)
            return;
          resolver.reject(new Error(message.payload));
        }
      });
    }
    sendRequest = ({ destination, payload }) => {
      return new Promise((resolve, reject) => {
        const request = {
          id: crypto.randomUUID(),
          type: "request" /* Request */,
          from: this.channel,
          to: destination,
          payload
        };
        this.requestPool.set(request.id, { resolve, reject });
        window.postMessage(request, "*");
      });
    };
    handleRequest;
  };
  var ChromeKernel = class {
    channel;
    requestPool;
    portName = "@berry/chrome-port";
    port = chrome.runtime.connect({ name: this.portName });
    currentSender;
    constructor(channel) {
      this.channel = channel;
      this.requestPool = /* @__PURE__ */ new Map();
      chrome.runtime.onConnect.addListener((port) => {
        if (port.name !== this.portName)
          return;
        port.onMessage.addListener(async (message) => {
          if (message.type === "request" /* Request */ && message.to === this.channel && this.handleRequest) {
            const response = {
              id: message.id,
              type: "response" /* Response */,
              from: this.channel,
              to: message.from,
              payload: null
            };
            this.currentSender = port.sender;
            try {
              response.payload = await this.handleRequest(message);
            } catch (error) {
              response.type = "reject" /* Reject */;
              response.payload = error.message;
            }
            port.postMessage(response);
          }
          if (message.type === "cross-resolve" /* CrossResolve */) {
            const resolver = this.requestPool.get(message.id);
            if (!resolver)
              return;
            resolver.resolve(message);
          }
          if (message.type === "cross-reject" /* CrossReject */) {
            const resolver = this.requestPool.get(message.id);
            if (!resolver)
              return;
            resolver.reject(new Error(message.payload));
          }
          if (message.type === "context-data" /* ContextData */) {
            const resolver = this.requestPool.get(message.payload);
            if (!resolver)
              return;
            port.postMessage({
              id: message.id,
              type: "response" /* Response */,
              from: this.channel,
              to: message.from,
              payload: resolver.data
            });
          }
        });
      });
      this.port.onMessage.addListener((message) => {
        console.log(`[ChromeKernel/${this.channel}] Received message`, message);
        if (message.type === "response" /* Response */) {
          const resolver = this.requestPool.get(message.id);
          if (!resolver)
            return;
          resolver.resolve(message);
        }
        if (message.type === "reject" /* Reject */) {
          const resolver = this.requestPool.get(message.id);
          if (!resolver)
            return;
          resolver.reject(new Error(message.payload));
        }
      });
    }
    sendRequest = async ({ destination, payload }) => {
      return new Promise((resolve, reject) => {
        const message = {
          id: crypto.randomUUID(),
          type: "request" /* Request */,
          from: this.channel,
          to: destination,
          payload
        };
        this.requestPool.set(message.id, { resolve, reject });
        this.port.postMessage(message);
      });
    };
    waitForResolve = ({ id, contextData }) => {
      return new Promise((resolve, reject) => {
        this.requestPool.set(id, { resolve, reject, data: contextData });
      });
    };
    requestContextData = ({ id, from }) => {
      return new Promise((resolve, reject) => {
        const message = {
          id: crypto.randomUUID(),
          type: "context-data" /* ContextData */,
          from: this.channel,
          to: from,
          payload: id
        };
        this.requestPool.set(message.id, { resolve, reject });
        this.port.postMessage(message);
      });
    };
    crossResolve = ({ id, destination, payload }) => {
      const message = {
        id,
        type: "cross-resolve" /* CrossResolve */,
        from: this.channel,
        to: destination,
        payload
      };
      this.port.postMessage(message);
    };
    crossReject = ({ id, destination, errorMessage }) => {
      const message = {
        id,
        type: "cross-reject" /* CrossReject */,
        from: this.channel,
        to: destination,
        payload: errorMessage
      };
      this.port.postMessage(message);
    };
    handleRequest;
  };

  // src/extension/utils.ts
  var injectScript = (scriptUri) => {
    try {
      const container = document.head || document.documentElement;
      const scriptTag = document.createElement("script");
      scriptTag.setAttribute("async", "false");
      scriptTag.src = chrome.runtime.getURL(scriptUri);
      container.insertBefore(scriptTag, container.children[0]);
      container.removeChild(scriptTag);
    } catch (error) {
      console.error("script injection failed.", error);
    }
  };

  // src/extension/content.ts
  (async () => {
    const webKernel = new WebKernel("@berry/content" /* Content */);
    const chromeKernel = new ChromeKernel("@berry/content" /* Content */);
    webKernel.handleRequest = async (request) => {
      const response = await chromeKernel.sendRequest({
        destination: "@berry/background" /* Background */,
        payload: request.payload
      });
      return response.payload;
    };
    injectScript("injection.js");
  })();
})();
