"use strict";
(() => {
  // src/messaging/core.ts
  var ChromeKernel = class {
    channel;
    requestPool;
    portName = "@berry/chrome-port";
    port = chrome.runtime.connect({ name: this.portName });
    currentSender;
    constructor(channel) {
      this.channel = channel;
      this.requestPool = /* @__PURE__ */ new Map();
      chrome.runtime.onConnect.addListener((port) => {
        if (port.name !== this.portName)
          return;
        port.onMessage.addListener(async (message) => {
          if (message.type === "request" /* Request */ && message.to === this.channel && this.handleRequest) {
            const response = {
              id: message.id,
              type: "response" /* Response */,
              from: this.channel,
              to: message.from,
              payload: null
            };
            this.currentSender = port.sender;
            try {
              response.payload = await this.handleRequest(message);
            } catch (error) {
              response.type = "reject" /* Reject */;
              response.payload = error.message;
            }
            port.postMessage(response);
          }
          if (message.type === "cross-resolve" /* CrossResolve */) {
            const resolver = this.requestPool.get(message.id);
            if (!resolver)
              return;
            resolver.resolve(message);
          }
          if (message.type === "cross-reject" /* CrossReject */) {
            const resolver = this.requestPool.get(message.id);
            if (!resolver)
              return;
            resolver.reject(new Error(message.payload));
          }
          if (message.type === "context-data" /* ContextData */) {
            const resolver = this.requestPool.get(message.payload);
            if (!resolver)
              return;
            port.postMessage({
              id: message.id,
              type: "response" /* Response */,
              from: this.channel,
              to: message.from,
              payload: resolver.data
            });
          }
        });
      });
      this.port.onMessage.addListener((message) => {
        console.log(`[ChromeKernel/${this.channel}] Received message`, message);
        if (message.type === "response" /* Response */) {
          const resolver = this.requestPool.get(message.id);
          if (!resolver)
            return;
          resolver.resolve(message);
        }
        if (message.type === "reject" /* Reject */) {
          const resolver = this.requestPool.get(message.id);
          if (!resolver)
            return;
          resolver.reject(new Error(message.payload));
        }
      });
    }
    sendRequest = async ({ destination, payload }) => {
      return new Promise((resolve, reject) => {
        const message = {
          id: crypto.randomUUID(),
          type: "request" /* Request */,
          from: this.channel,
          to: destination,
          payload
        };
        this.requestPool.set(message.id, { resolve, reject });
        this.port.postMessage(message);
      });
    };
    waitForResolve = ({ id, contextData }) => {
      return new Promise((resolve, reject) => {
        this.requestPool.set(id, { resolve, reject, data: contextData });
      });
    };
    requestContextData = ({ id, from }) => {
      return new Promise((resolve, reject) => {
        const message = {
          id: crypto.randomUUID(),
          type: "context-data" /* ContextData */,
          from: this.channel,
          to: from,
          payload: id
        };
        this.requestPool.set(message.id, { resolve, reject });
        this.port.postMessage(message);
      });
    };
    crossResolve = ({ id, destination, payload }) => {
      const message = {
        id,
        type: "cross-resolve" /* CrossResolve */,
        from: this.channel,
        to: destination,
        payload
      };
      this.port.postMessage(message);
    };
    crossReject = ({ id, destination, errorMessage }) => {
      const message = {
        id,
        type: "cross-reject" /* CrossReject */,
        from: this.channel,
        to: destination,
        payload: errorMessage
      };
      this.port.postMessage(message);
    };
    handleRequest;
  };

  // src/utils/constants.ts
  var WINDOW_WIDTH = 400;
  var WINDOW_HEIGHT = 600;

  // src/extension/utils.ts
  var WINDOW_SCROLLBAR_WIDTH = 4;
  var WINDOW_TITLE_HEIGHT = 28;
  var openPopup = async (event, messageId) => {
    const lastFocusedWindow = await chrome.windows.getLastFocused();
    const { top, left = 0, width = 0 } = lastFocusedWindow;
    const leftPos = left + width - WINDOW_WIDTH;
    return await chrome.windows.create({
      top,
      left: leftPos,
      type: "popup",
      width: WINDOW_WIDTH + WINDOW_SCROLLBAR_WIDTH,
      height: WINDOW_HEIGHT + WINDOW_TITLE_HEIGHT,
      url: `index.html#/request/${event}/${messageId}`,
      focused: true
    });
  };

  // src/extension/background.ts
  var chromeKernel = new ChromeKernel("@berry/background" /* Background */);
  var currentPublicKey = null;
  chromeKernel.handleRequest = async (request) => {
    switch (request.payload.event) {
      case "connect" /* Connect */: {
        const payload = request.payload;
        if (payload.options?.onlyIfTrusted && currentPublicKey) {
          return currentPublicKey;
        }
        const resolveId = crypto.randomUUID();
        openPopup(payload.event, resolveId);
        const response = await chromeKernel.waitForResolve({
          id: resolveId,
          contextData: {
            sender: chromeKernel.currentSender
          }
        });
        currentPublicKey = response.payload;
        return response.payload;
      }
      case "sign-transaction" /* SignTransaction */: {
        const payload = request.payload;
        const resolveId = crypto.randomUUID();
        openPopup(payload.event, resolveId);
        const response = await chromeKernel.waitForResolve({
          id: resolveId,
          contextData: {
            sender: chromeKernel.currentSender,
            encodedTransaction: payload.encodedTransaction
          }
        });
        return response.payload;
      }
      case "sign-and-send-transaction" /* SignAndSendTransaction */: {
        const payload = request.payload;
        const resolveId = crypto.randomUUID();
        openPopup(payload.event, resolveId);
        const response = await chromeKernel.waitForResolve({
          id: resolveId,
          contextData: {
            sender: chromeKernel.currentSender,
            encodedTransaction: payload.encodedTransaction,
            options: payload.options
          }
        });
        return response.payload;
      }
      case "sign-message" /* SignMessage */: {
        const payload = request.payload;
        const resolveId = crypto.randomUUID();
        openPopup(payload.event, resolveId);
        const response = await chromeKernel.waitForResolve({
          id: resolveId,
          contextData: {
            sender: chromeKernel.currentSender,
            encodedMessage: payload.encodedMessage
          }
        });
        return response.payload;
      }
      default:
        throw new Error("Method not implemented.");
    }
  };
})();
